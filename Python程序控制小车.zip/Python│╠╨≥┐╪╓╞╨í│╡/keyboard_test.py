import requests
import time
import keyboard
def go_forward():
    requests.post('http://192.168.4.1/motor_control?speed=60')

def go_back():
    requests.post('http://192.168.4.1/motor_control?speed=-60')

def stop():
    requests.post('http://192.168.4.1/motor_control?speed=0')

def go_left():
    r = requests.post('http://192.168.4.1/servo_control?angle=30')

def go_right():
    r = requests.post('http://192.168.4.1/servo_control?angle=135')

def go_straight():
    r = requests.post('http://192.168.4.1/servo_control?angle=90')

def angle():
    a = input("please input the angle you want:")
    r = requests.post(f"http://192.168.4.1/servo_control?angle={a}")


if __name__ == '__main__':
    keyboard.add_hotkey('w',go_forward)
    keyboard.add_hotkey('s',go_back)
    keyboard.add_hotkey('a',go_left)
    keyboard.add_hotkey('d',go_right)
    keyboard.add_hotkey('q',stop)
    keyboard.add_hotkey('x',angle)
    keyboard.wait()
