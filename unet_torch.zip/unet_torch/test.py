import torch
a = 1
print(a)